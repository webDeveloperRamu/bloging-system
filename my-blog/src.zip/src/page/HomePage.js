// inporting react
import React from 'react';
const HomePage = () => (
    // <React.Fragment>
    <>
        <h1>This is the home page </h1>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
        </p>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
        </p>
        {/* <footer>
            <p>&copy; @_abhi_singh 2023 </p>
        </footer> */}
    </>


);
export default HomePage;