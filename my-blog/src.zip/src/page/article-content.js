
const articleContent=[
    {
        name:'learn-react',
        title:'The fast way to learn React',
        content:[
            ` Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
           Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            `,
            ` Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
           Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            `,
            ` Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
           Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            `,
        ]
    },
    {
        name:'learn-node',
        title:'very easy way to learn Node ',
        content:[
            ` Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            `,
        ]
    },
    {
        name:'learn-express',
        title:'The fast way to learn Express',
        content:[
            ` Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            `,
        ]
    },
    {
        name:'my-thoughte-on-resumes',
        title:'The fast way to learn MongoDB',
        content:[
            ` Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quod in ratione quibusdam optio fuga eius voluptates eaque quia nesciunt.
            `,
        ]
    },
];
export default articleContent;