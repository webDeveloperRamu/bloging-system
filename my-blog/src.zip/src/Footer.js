import React from 'react';
const Footer=()=>(
    <>
    <footer>
        <p>&copy; @_abhi_singh 2023 </p>
    </footer>
    </>
);
export default Footer;